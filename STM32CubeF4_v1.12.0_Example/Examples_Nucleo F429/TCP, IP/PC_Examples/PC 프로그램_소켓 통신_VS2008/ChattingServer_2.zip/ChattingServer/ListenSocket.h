#pragma once
#include "afxcoll.h"

#include "ChildSocket.h"	// �߰� onDestory()���� �ʿ�

// CListenSocket ���� ����Դϴ�.

class CListenSocket : public CAsyncSocket
{
public:
	CListenSocket();
	virtual ~CListenSocket();

	virtual void OnAccept(int nErrorCode);
	void CloseClientSocket(CSocket* pChild);
	void BroadCast(char* pszBuffer, int len);

	CPtrList m_ptrChildSocketList;
};


